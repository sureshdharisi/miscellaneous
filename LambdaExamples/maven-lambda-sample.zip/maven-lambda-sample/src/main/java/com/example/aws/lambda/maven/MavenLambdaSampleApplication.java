package com.example.aws.lambda.maven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenLambdaSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MavenLambdaSampleApplication.class, args);
	}

}
