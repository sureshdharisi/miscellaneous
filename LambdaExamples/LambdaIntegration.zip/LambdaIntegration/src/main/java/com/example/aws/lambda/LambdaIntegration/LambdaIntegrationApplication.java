package com.example.aws.lambda.LambdaIntegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LambdaIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(LambdaIntegrationApplication.class, args);
	}

}
